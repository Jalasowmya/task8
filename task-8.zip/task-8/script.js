// Optional custom JS can go here
// Example: console log for testing
console.log("Responsive Blog Layout Loaded");